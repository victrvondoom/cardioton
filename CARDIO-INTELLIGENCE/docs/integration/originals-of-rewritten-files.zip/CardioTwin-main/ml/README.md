# cardiotwin_ml — prediction pipeline

Predicts **overall coronary artery disease (CAD)** and **vessel-level stenosis (LAD, LCX, RCA)** from routine
clinical data, explains every prediction with **exact SHAP values**, and exports a **portable JSON model** that the
browser evaluates bit-for-bit. Headline results live in [`reports/results.md`](reports/results.md) (generated) and the
[model card](../docs/MODEL_CARD.md).

```
data/raw/*.xlsx ─► preprocess ─► locked split ─► ablations ─► nested-CV leaderboard + cross-fitted ensemble estimate
                                                                                           │
                         final tuning on dev ─► OOF CV with final hyper-parameters ─► w / Platt / threshold
                                                                                           │
            docs/figures ◄─ report ◄─ metrics.json ◄─ single test evaluation ◄─ refit on dev ┘
                                         │
      ml/artifacts/{schema,model,metrics,cohort,fixtures}.json + cardiotwin_models.joblib ──► frontend/public/model
```

## Headline results

Locked test set (61 unseen patients; 95 % stratified-bootstrap CIs) and development CV (repeated stratified
5-fold × 10, nested tuning, ensemble choices cross-fitted). Full tables: [`reports/results.md`](reports/results.md).

| Target | Test ROC-AUC | Test F1 | Test sensitivity / specificity | Test Brier | Dev-CV ROC-AUC |
| --- | --- | --- | --- | --- | --- |
| CAD | 0.858 (0.743–0.955) | 0.871 (0.791–0.940) | 0.841 / 0.765 | 0.123 | 0.937 ± 0.034 |
| LAD | 0.742 (0.612–0.858) | 0.694 (0.580–0.800) | 0.694 / 0.560 | 0.217 | 0.867 ± 0.057 |
| LCX | 0.814 (0.701–0.907) | 0.712 (0.600–0.808) | 0.840 / 0.639 | 0.177 | 0.738 ± 0.053 |
| RCA | 0.759 (0.627–0.866) | 0.610 (0.491–0.714) | 0.783 / 0.526 | 0.183 | 0.727 ± 0.071 |

On the development leaderboard the ensemble ranks first for LAD and LCX and second for CAD and RCA (differences far
below the fold-to-fold sd). On the test set it does not significantly beat a 5-feature clinical baseline (age, sex,
typical angina, DM, HTN; paired ΔAUC CIs include 0) — reported honestly in the [model card](../docs/MODEL_CARD.md),
together with the CV-to-test gap that the baseline shows as well. v1.1.0 fixed a calibration defect found in review
(model card §11); the test set has been scored once per release.

![Test ROC-AUC vs baseline](../docs/figures/test_auc_forest.png)

### Beyond one 61-patient split

**Robustness — Monte-Carlo repeated hold-out (200 splits).** The whole recipe (hyper-parameter search, out-of-fold
weight/Platt/threshold fitting, refit) was re-run inside the development part of 200 random stratified 80/20 splits
and scored once on each split's test part. Median (5th–95th percentile) held-out ROC-AUC:

| Target | Locked test ROC-AUC | Monte-Carlo ROC-AUC | Locked split's percentile | Full panel beats clinical baseline |
| --- | --- | --- | --- | --- |
| CAD | 0.858 | 0.934 (0.864–0.975) | 3rd | 84 % of splits (mean ΔAUC +0.024) |
| LAD | 0.742 | 0.844 (0.771–0.909) | 2nd | 92 % of splits (+0.046) |
| LCX | 0.814 | 0.762 (0.672–0.833) | 84th | 76 % of splits (+0.010) |
| RCA | 0.759 | 0.751 (0.660–0.828) | 58th | 69 % of splits (+0.006) |

The locked split is among the hardest 3 % for CAD and LAD — the clinical baseline also scores at its 4th / 14.5th
percentile there — while the cross-fitted CV estimates sit at the 52nd / 78.5th percentile of the Monte-Carlo
distribution: the CV-to-test gap is split difficulty, not overfitting. Re-searching the hyper-parameters in every
split instead of reusing the deployed ones changes the mean ROC-AUC by ≤ 0.0007 (no tuning optimism), and the median
calibration slope is 0.97–1.04 for every target (the locked split's 0.62 / 0.47 for CAD / LAD are at its 6th / 2nd
percentile).

**Multimodality — what ECG, labs and echo add (development CV, 50 paired folds, corrected-t 95 % CIs).** Adding
the instrumental modalities to bedside information (demographics, history, symptoms, examination) raises ROC-AUC by
**+0.028 (+0.002 to +0.054) for CAD** and **+0.069 (+0.024 to +0.115) for LAD**; +0.028 and +0.021 for LCX and RCA
(CIs include 0). Echocardiography carries the unique information (removing it costs −0.021 CAD, −0.047 LAD), ECG adds
none once echo and labs are present, and the laboratory panel helps the circumflex and RCA models most (+0.041 /
+0.028, not significant after Holm correction). Symptoms (typical angina) remain the most informative single modality.

![Monte-Carlo repeated hold-out](../docs/figures/robustness.png)

![Modality ablation](../docs/figures/modality_ablation.png)

## Quick start

Prerequisites: Python 3.11, ~1 GB RAM, any CPU (no GPU).

```bash
python -m venv .venv
./.venv/Scripts/python -m pip install -r ml/requirements.txt     # exact versions used for the published artifacts
./.venv/Scripts/python -m pip install -e ml                        # editable install of cardiotwin_ml

./.venv/Scripts/python -m cardiotwin_ml.train                      # full deterministic run -> artifacts, figures, report
                                                                   # (~4 min with 12 CPU workers)
./.venv/Scripts/python -m cardiotwin_ml.analysis --jobs 8         # validation analyses -> metrics.json, figures, report
                                                                   # (~40 min with 8 workers; keep --jobs <= 8)
./.venv/Scripts/python -m pytest ml/tests -q                       # test-suite (uses the built artifacts)
```

(On macOS/Linux use `.venv/bin/python`.) Useful flags: `--fast` (reduced CV/search/bootstrap smoke run),
`--dev-only` (development-set CV only; never touches the test set), `--out DIR` (write artifacts elsewhere; skips
figures and the frontend mirror), `--jobs N`. Regenerate figures without retraining:
`python -m cardiotwin_ml.report`. Re-download and verify the dataset: `python -m cardiotwin_ml.data`.
Analysis flags: `--only robustness|modality|subgroups` (re-run a subset; other analyses are kept), `--splits N`,
`--hyperparameters search|frozen`, `--cache DIR` (memoise the expensive runs), `--fast --out DIR` (smoke run).

## Package layout

| Module | Responsibility |
| --- | --- |
| `data.py` | UCI download, SHA-256 verification, raw loading |
| `config.py` + `configs/*.yaml` | feature registry (`features.yaml`), targets + anatomy (`targets.yaml`), protocol & model zoo (`training.yaml`) |
| `preprocess.py` | encoding normalisation, **leakage guard** (`LEAKAGE_COLUMNS`), derived features, `FeatureEncoder` |
| `splits.py` | locked hold-out split stratified on the joint CAD/LAD/LCX/RCA pattern |
| `models.py` | estimator factories + search spaces (all wrapped in scikit-learn pipelines) |
| `evaluate.py` | repeated stratified CV, nested RandomizedSearchCV, out-of-fold predictions |
| `ablation.py` | derived features / feature selection / classifier-chain ablations (paired, dev only) |
| `ensemble.py` | margin ensemble, Platt calibration, thresholds, deployed `TargetModel` |
| `xgb_trees.py` | float64 XGBoost leaf-sum margins and exact path-dependent TreeSHAP |
| `explain.py` | ensemble SHAP, one-hot aggregation, global importance, beeswarm, library cross-checks |
| `metrics.py` | metrics, stratified bootstrap CIs, ROC/PR/calibration/decision curves |
| `export.py`, `fixtures.py` | artifacts (`schema`, `model`, `cohort`, `fixtures`, joblib) and parity fixtures |
| `inference.py` | `CardioTwinPredictor` used by the FastAPI backend |
| `portable.py` | stdlib-only reference evaluator of `model.json` (spec for the TypeScript engine) |
| `report.py` | figures (`docs/figures`) and `reports/results.md` |
| `train.py` | one-command orchestration |
| `analysis/` | validation analyses behind `python -m cardiotwin_ml.analysis`: `robustness.py` (Monte-Carlo repeated hold-out of the frozen recipe), `modality.py` (modality ablation), `subgroups.py`, `stats.py` (corrected-t, Holm, percentiles), `summary.py` (additive `metrics.json` merge, `metrics_summary.json`) |

## Extending

* **New clinical feature** — add an entry to `configs/features.yaml` (key = dataset column, group, type, unit, normal
  range, description). Encoding, schema, portable model, explanations and UI tooltips follow automatically.
* **New derived feature** — add it under `derived:` with an existing `op` (`ratio`, `sum`, `ckd_epi_2021`). It is
  adopted only if the dev-CV ablation shows a gain; explanations report it as its own row with `derived_from`.
* **New target** (e.g. left main) — add an entry to `configs/targets.yaml` (`source_column`, `positive_values`,
  `kind`, `anatomy` node names). Every stage loops over the registry; the source column is automatically a
  leakage column (validated at load).
* **New model** — add a `models:` entry in `configs/training.yaml` (existing `kind`) or one factory in `models.py`;
  it joins the nested-CV leaderboard.

## Validation protocol (summary)

1. **Locked test set** — 20 % (61 patients), seed 42, stratified on the joint CAD/LAD/LCX/RCA pattern (the single
   `0100` patient is merged into `0000`). Scored once per release, after every decision is frozen; only the deployed
   ensemble and the pre-specified clinical baseline are evaluated on it. Every release that re-scored it is listed,
   with the reason, in `training.yaml → holdout.history` and `metrics.json → protocol.test_set_history`.
2. **Development CV** — repeated stratified 5-fold × 10 per target; the same folds for every model (paired).
   Imputation/scaling live inside pipelines, so they are fitted in-fold.
3. **Nested tuning** — LR (L2, L1, elastic net, clinical core), SVM, kNN and XGBoost are tuned by
   `RandomizedSearchCV` on **log-loss** over an inner stratified 5-fold split inside each outer training fold
   (ROC-AUC is nearly flat in the regularisation strength and drove `C` to the edge of its range).
4. **Ablations** — derived features, in-fold selection and a leakage-free classifier chain are compared with the raw
   feature set on identical folds; adopted only if the mean ROC-AUC gain ≥ 0.005.
5. **Honest ensemble estimate** — the ensemble's CV row is *cross-fitted*: for every outer fold the logistic variant,
   `w`, Platt parameters and threshold are re-chosen on the other folds of that repeat only
   (`ensemble.cross_fit_ensemble`), so no reported CV number was used to make a choice it is scored on.
6. **Deployed model** — logistic variant = best nested-CV ROC-AUC; component hyper-parameters searched on the full dev
   set; then a 10 × 5 CV **with those final hyper-parameters** produces OOF margins on which `w` (pooled log-loss after
   Platt), `p = σ(a·m + b)` and the Youden threshold (F1-optimal reported too) are fitted — so the calibration map
   matches the scale of the deployed margins. Components are refitted on the full dev set; **the test set never
   influences the deployed model**.
7. **Test metrics** — accuracy, precision, recall, specificity, F1, ROC-AUC, PR-AUC, Brier, log-loss, MCC, balanced
   accuracy with 2000× stratified bootstrap 95 % CIs; confusion matrix; calibration slope/intercept and ECE; ROC (with
   bootstrap band), PR, reliability and decision curves; paired-bootstrap ΔAUC against the clinical baseline.

## Validation analyses (`python -m cardiotwin_ml.analysis`)

Descriptive analyses that put the single locked test set into context. They never refit, recalibrate or re-threshold
the deployed model; results are added to `metrics.json` (keys documented under *Artifacts*), drawn in
`docs/figures/{robustness,modality_ablation,subgroups}.png` and tabulated in `reports/results.md`. Settings live in
`training.yaml → analysis`; every run is seeded and independent of `--jobs` (≈ 40 min on 8 workers, dominated by the
200 × 4 hyper-parameter searches; `--cache DIR` memoises them).

1. **Robustness** (`analysis/robustness.py`) — 200 Monte-Carlo splits (`random_state = 1000 + i`), stratified on the
   joint label pattern like the locked split. Frozen: encoding, model families, per-target logistic variant, search
   spaces and rules. Re-derived inside each split's development part: hyper-parameters (the deployed
   `RandomizedSearchCV` on log-loss), 10 × 5-fold OOF margins → `w`, Platt `a, b`, Youden threshold, refit; the clinical
   baseline likewise. The harness is validated on the locked split, where it reproduces the deployed test
   probabilities **bit for bit** (`analysis.robustness.reproduction`). A sensitivity run reuses the deployed
   hyper-parameters on the same splits. Output: distributions of 12 held-out metrics, the locked split's percentile,
   the paired gain over the baseline and the per-split samples. Test parts overlap across splits, so the spread
   describes the variability of a 61-patient evaluation, not independent replications.
2. **Modality ablation** (`analysis/modality.py`) — development set only, the leaderboard's repeated stratified
   5-fold × 10: cumulative (demographics → +risk factors → +symptoms → +exam → +ECG → +labs → +echo),
   leave-one-modality-out and single-modality sets, one fixed model for all sets (equal-weight LR + XGBoost margin
   ensemble with the `ablations.fixed_params`). Per-fold paired differences with Nadeau–Bengio corrected resampled
   t intervals (fold estimates share training data; the naive SE would be ~3× too small) and Holm adjustment within
   each family.
3. **Subgroups** (`analysis/subgroups.py`) — sex, age band (< 50, 50–65, > 65 years) and diabetes, on the cross-fitted
   development OOF predictions (recomputed exactly: they reproduce `targets.<t>.cv`) and on the locked test set;
   stratified (OOF: patient-cluster) bootstrap CIs, `delta_roc_auc_vs_reference` against the largest level, `small_n`
   flags (< 30 patients or < 10 per class) and `null` for metrics of classes with < 3 patients. Findings (OOF,
   unadjusted, exploratory): CAD discrimination is similar across all subgroups (0.90–0.98); vessel-level
   discrimination is lower in patients over 65 (LCX 0.54 vs 0.75 at 50–65, Δ −0.21, 95 % CI −0.36 to −0.05) and with
   diabetes (LAD 0.75 vs 0.88, Δ −0.14, −0.26 to −0.02), where most patients are flagged (specificity 0.21–0.45);
   calibration-in-the-large stays within ±0.09 in every subgroup.

## Explainability

SHAP values are exact and live in the ensemble's **log-odds space**:

* logistic component — linear SHAP w.r.t. the development-set mean, `φ_j = β_j/σ_j · (x_j − x̄_j)`;
* XGBoost component — path-dependent TreeSHAP (Lundberg et al. 2018, Algorithm 2) with node covers, re-implemented
  in **float64** (`xgb_trees.py`) because XGBoost's own `pred_contribs` accumulates in float32 and misses the 1e-6
  additivity contract by up to ~1e-5. Agreement with `pred_contribs` and with the `shap` library is checked on every
  run (`metrics.json → explainability_checks`: ≤ 5e-7 on the deployed models, i.e. float32 precision);
* ensemble — `φ = w·φ_LR + (1−w)·φ_XGB`, `base = w·base_LR + (1−w)·base_XGB`, so `base + Σφ = margin` (asserted
  to 1e-6, observed ≈ 1e-15). One-hot columns (`BBB`) are summed back into their raw feature;
* calibrated scale — the displayed probability is `σ(a·margin + b)`, so each response also carries
  `shap_calibrated = a·φ`, `calibrated_base_value = a·base + b` and `calibrated_output_value = a·margin + b`
  (`σ(calibrated_output_value)` is the probability). Use these when a chart must add up to the probability shown.

## Portable model format

`model.json` (`format = "cardiotwin-portable-model"`, `format_version = "1.0.0"`) contains everything needed to
predict and explain in the browser. Reference implementation: [`src/cardiotwin_ml/portable.py`](src/cardiotwin_ml/portable.py)
(standard library only; port it line by line). `fixtures.json` holds ≥ 30 request/response pairs the port must
reproduce to `|Δp| < 1e-6`, `|Δshap| < 1e-5` (the Python reference achieves < 1e-9).

### Top level

| Field | Type | Meaning |
| --- | --- | --- |
| `format`, `format_version` | string | format identifier / version of this layout |
| `model_version` | string | model release (matches the API `model_version`) |
| `margin_space` | `"log-odds"` | space of every margin, base value and SHAP value |
| `targets` | string[] | target ids in display order (`CAD`, `LAD`, `LCX`, `RCA`) |
| `vessel_targets` | string[] | targets summed into `summary.expected_diseased_vessels`; `highest_risk_vessel` = argmax |
| `features` | object[] | raw API inputs, in encoding order: `{key, type, default, options?, aliases?}` |
| `columns` | string[] | encoded model columns (length *d*); every vector below is indexed by this order |
| `encoding` | object[] | how each raw feature becomes columns (see below) |
| `derived` | object[] | derived columns appended after the encoded raw columns (may be empty) |
| `constants` | object | `ratio_min_denominator`, `ckd_epi_min_creatinine` used by derived ops |
| `attribution` | object[] | contribution rows: `{feature, columns, column_indices, derived_from?}` — SHAP of a row = Σ SHAP of its columns |
| `risk_bands` | object[] | `{id, max}` in ascending order; band = first with `p < max` (else the last) |
| `models` | object | per target id, see *Target model* |

### Input normalisation (`features`)

* Unknown keys → error. Missing or `null` keys → `default` and listed in `imputed` (in `features` order).
* `binary`: accepts `0/1`, `true/false`, and case-insensitive `"1"/"0"`, `"y"/"n"`, `"yes"/"no"`, `"true"/"false"`, `"t"/"f"`.
* `categorical`: case-insensitive match against `options`; `aliases` maps dataset spellings (e.g. `"Fmale" → "Female"`).
* `numeric`: any finite number or numeric string (no clamping — trees extrapolate flat, the logistic part linearly).

### `encoding[]`

| `kind` | Fields | Columns produced |
| --- | --- | --- |
| `numeric` | `feature`, `column` | `float(value)` |
| `binary` | `feature`, `column` | `0.0` / `1.0` |
| `ordinal` | `feature`, `column`, `map` | `map[value]` (e.g. `VHD`: N 0, mild 1, Moderate 2, Severe 3; `Sex`: Female 0, Male 1) |
| `onehot` | `feature`, `categories`, `columns` | one column per category, `1.0` for the matching category |

`derived[]` entries are `{feature, column, op, inputs}` with `op` ∈ `ratio` (`inputs[0] / max(inputs[1], ratio_min_denominator)`),
`sum` (Σ inputs), `ckd_epi_2021` (race-free CKD-EPI 2021 eGFR from creatinine, age, sex — see `portable.derived_value`).

### Target model (`models[target]`)

| Field | Meaning |
| --- | --- |
| `components` | list of margin models; ensemble margin `m = Σ_k weight_k · m_k` (weights sum to 1) |
| `calibration` | `{method: "platt", a, b}` → `p = 1 / (1 + exp(−(a·m + b)))` |
| `threshold` | decision threshold on `p` (Youden's J on out-of-fold dev predictions); `label = p ≥ threshold` |
| `threshold_f1` | F1-optimal alternative threshold (informational) |
| `base_value` | `Σ_k weight_k · components[k].base_value` — the SHAP base value `E[m]` |

**Logistic component** (`type = "logistic"`): `name`, `weight`, `intercept`, `coef[d]`, `scaler.mean[d]`,
`scaler.scale[d]`, `background_mean[d]`, `base_value`.

```
m_LR    = intercept + Σ_j coef[j] · (x[j] − mean[j]) / scale[j]          (sum j = 0..d−1 in order)
φ_LR[j] = (x[j] − background_mean[j]) · (coef[j] / scale[j])
```

**XGBoost component** (`type = "xgboost"`): `name`, `weight`, `objective` (`binary:logistic`), `base_score`
(probability space, as stored by XGBoost 3.x), `n_trees`, `base_value`, `trees[]` in XGBoost JSON-dump form:

| Node field | Meaning |
| --- | --- |
| `nodeid` | node id, unique within the tree (root = 0) |
| `split`, `split_index` | column name / index into `columns` |
| `split_condition` | threshold (a float32 value stored as the exact double) |
| `yes`, `no`, `missing` | child node ids: `x < split_condition` → `yes`, otherwise `no`; NaN → `missing` |
| `cover` | sum of hessians of training rows reaching the node (TreeSHAP weights) |
| `leaf` | leaf value (present only on leaves; already scaled by the learning rate) |
| `children` | nested child nodes (internal nodes only) |

```
compare:  fround(x[split_index]) < fround(split_condition)      // float32, like XGBoost; fround = Math.fround
m_XGB   = log(base_score / (1 − base_score)) + Σ_trees leaf      // float64, trees in order
φ_XGB   = path-dependent TreeSHAP over all trees (portable.xgboost_shap), zero/one fractions from `cover`
```

### Response assembly

For each target: `margin = Σ w_k m_k`, `p = σ(a·margin + b)`, `label`, `risk_band`, `logit = margin`,
`explanations.base_value = Σ w_k base_value_k`, `output_value = margin`,
`calibrated_base_value = a·base_value + b`, `calibrated_output_value = a·margin + b`, and `contributions` = one row per
`attribution` entry (`{feature, value, shap, shap_calibrated = a·shap}` + `derived_from` for derived rows) sorted by `|shap|` descending (ties by
name). Numeric `value`s are emitted as integers when integral. `summary.expected_diseased_vessels = Σ_vessels p`,
`summary.highest_risk_vessel = argmax_vessels p`.

## Artifacts

| File | Consumer | Content |
| --- | --- | --- |
| `schema.json` | backend, frontend | feature metadata (labels, groups, units, ranges, defaults, reference ranges, descriptions), targets + anatomy + thresholds, risk bands |
| `model.json` | frontend edge engine | portable model (above) |
| `metrics.json` | backend, frontend | protocol, dataset, ablations, per-target CV + test metrics with CIs, curves, leaderboard, SHAP importance and beeswarm, checks; plus `robustness`, `modality_ablation`, `subgroups`, `analysis` (below) |
| `metrics_summary.json` | frontend landing page | ~20 kB compact extract of `metrics.json`: headline test/CV metrics with CIs, robustness and modality headlines (below) |
| `cohort.json` | backend, frontend | all 61 test patients (unseen by the model) + 20 dev demo patients with ground truth |
| `fixtures.json` | parity tests | request → expected response pairs, with encoded vectors |
| `cardiotwin_models.joblib` | backend | native scikit-learn / XGBoost models (weights deliverable) |

All JSON artifacts are deterministic: reruns (also with a different `--jobs`) reproduce every file byte for byte,
except `metrics.json → generated_at`.

### Validation-analysis keys in `metrics.json`

Added by `python -m cardiotwin_ml.analysis` (docs/CONTRACTS.md §7.2); every key is optional for consumers and each
per-target map is keyed by target id in display order. Existing keys are never modified (the merge re-serialises
them byte for byte and refuses otherwise).

| Key | Shape |
| --- | --- |
| `robustness.<target>` | `n_splits`; `fixed_split_percentile` (percentile of the locked split's test ROC-AUC in the Monte-Carlo distribution); per metric (`roc_auc`, `pr_auc`, `f1`, `recall`, `specificity`, `accuracy`, `balanced_accuracy`, `mcc`, `brier`, `log_loss`, `calibration_slope`, `calibration_in_the_large`) `{n, mean, sd, p05, p25, p50, p75, p95, min, max, fixed_split, fixed_split_percentile}`; `baseline_roc_auc`, `delta_roc_auc_vs_baseline` (+ `share_positive`); `cv_estimate {roc_auc, percentile}`; `recipe` (distributions of `weight_lr`, `platt_a`, `threshold`); `samples {roc_auc, f1, brier}` (one value per split, for histograms); `hyperparameter_sensitivity` |
| `modality_ablation.<target>` | `full {n_columns, roc_auc}`; `cumulative[]`, `leave_one_out[]`, `single[]` rows `{id, group, label, groups, n_columns, roc_auc {mean, sd, se, ci, n_folds}, lr_roc_auc, xgb_roc_auc}` with `delta_vs_previous` (cumulative; `null` for the first step) or `delta_vs_full` (leave-one-out) `{mean, se, ci, p_value, p_holm, share_folds_improved}`; `instrumental {bedside_groups, added_groups, bedside_roc_auc, full_roc_auc, delta}` |
| `subgroups.<target>` | `overall {oof, test}`; `factors.{sex, age_band, diabetes} = {label, reference, levels[] {id, label, oof, test}}`; each block `{n, n_pos, prevalence, roc_auc, sensitivity, specificity, ppv, f1, brier, calibration_in_the_large, mean_predicted, small_n, delta_roc_auc_vs_reference}` with metrics as `{value, ci}` or `null` when not estimable (< 3 patients in the class) |
| `analysis` | `version`, `command`, `fingerprint` (sha-256 of `model.json`, dataset, `features.yaml`, `targets.yaml` and the training config without its `analysis` section), `note`, and per analysis its method, settings, checks and `fast_mode` |

`train.py` keeps these keys when it is re-run and the fingerprint is unchanged (a deterministic rerun reproduces
`model.json`); otherwise it drops them and asks for `python -m cardiotwin_ml.analysis`.

### `metrics_summary.json`

Compact single-line JSON (~20 kB) written next to `metrics.json` by `train.py` and by the analysis command, and
mirrored to `frontend/public/model`, so the landing page does not have to download the 1.5 MB `metrics.json`. It is
a pure extract: every number also appears in `metrics.json` (checked by `tests/test_analysis.py`).

| Field | Content |
| --- | --- |
| `format`, `format_version` | `"cardiotwin-metrics-summary"`, `"1.0.0"` |
| `model_version`, `source`, `metrics_generated_at` | model release, `"metrics.json"`, its `generated_at` |
| `dataset` | `name`, `n`, `n_dev`, `n_test`, `prevalence` per target |
| `protocol` | one-line descriptions of the test CIs (`test`) and the CV estimate (`cv`) |
| `targets.<id>.label`, `.threshold` | display label (from `schema.json`) and deployed Youden threshold |
| `targets.<id>.test` | `{value, ci}` for `roc_auc`, `pr_auc`, `f1`, `precision`, `recall`, `specificity`, `accuracy`, `balanced_accuracy`, `mcc`, `brier` |
| `targets.<id>.cv` | `{mean, std}` for `roc_auc`, `pr_auc`, `f1`, `recall`, `specificity`, `accuracy`, `brier` |
| `targets.<id>.calibration` | test `calibration_slope`, `calibration_in_the_large`, `ece` |
| `targets.<id>.baseline` | clinical-baseline `features`, `test_roc_auc {value, ci}`, paired `delta_roc_auc {value, ci, p_value_one_sided}` |
| `targets.<id>.robustness` | *(when analysed)* `n_splits`, `fixed_split_percentile`, `roc_auc` / `f1` / `brier` / `calibration_slope` `{mean, sd, p05, p50, p95, fixed_split, fixed_split_percentile}`, `delta_roc_auc_vs_baseline {mean, p05, p50, p95, share_positive}` |
| `targets.<id>.modality` | *(when analysed)* `full_roc_auc {mean, ci}`; `cumulative[] {group, label, roc_auc {mean, ci}, delta {mean, ci, p_holm} \| null}`; `unique_contribution[] {group, label, delta_if_removed {mean, ci, p_holm}}`; `instrumental {bedside_roc_auc, full_roc_auc, delta {mean, ci, p_value, share_folds_improved}, added_groups}` |
| `headline` | `robustness {text, n_splits, median_roc_auc, fixed_split_percentile}`, `modality {text, instrumental_delta, most_informative_modality}`, `labels` — ready-to-display sentences and numbers |
